#include "loader.h"
Elf32_Ehdr *elf_header;
Elf32_Phdr *program_header;
int f_des;
void *v_mem;
void load_and_execute_elf(char** executable) {
  f_des = open(executable[1], O_RDONLY);
  elf_header = (Elf32_Ehdr*)malloc(sizeof(Elf32_Ehdr));
  read(f_des, elf_header, sizeof(Elf32_Ehdr));
  program_header = (Elf32_Phdr*)malloc(sizeof(Elf32_Phdr)* elf_header->e_phnum);
  lseek(f_des , elf_header->e_phoff , SEEK_SET); 
  read(f_des , program_header , sizeof(Elf32_Phdr)*elf_header->e_phnum);
  int i = 0;
  for (int i = 0 ; i< elf_header->e_phnum ; i++){
    if(program_header[i].p_type == PT_LOAD && elf_header->e_entry >= program_header[i].p_vaddr && elf_header->e_entry < program_header[i].p_vaddr + program_header[i].p_memsz){
      v_mem = mmap((void*)program_header[i].p_vaddr , program_header[i].p_memsz, PROT_READ | PROT_WRITE | PROT_EXEC | PROT_GROWSUP | PROT_GROWSDOWN, MAP_PRIVATE, f_des , program_header->p_offset);
      lseek(f_des , program_header[i].p_offset , program_header[i].p_memsz);
      read(f_des , v_mem , program_header[i].p_memsz);
      printf("increment: %d\n", elf_header->e_entry - program_header[i].p_vaddr);
      break ; 
    }
  }
  int answer = (int)v_mem + elf_header->e_entry - program_header[i].p_vaddr;
  int (*_start)() = (int (*)(void))answer;
  printf("%x\n",(int) v_mem);
  int result = (*_start)();
  printf("User _start return value = %d\n",result);
}
void loader_cleanup() {
  free(elf_header);
  free(program_header);
  munmap(v_mem, program_header->p_memsz);
}

int main(int argc, char** argv){
  if(argc != 2){
    printf("Usage: %s <ELF Executable> \n",argv[0]);
    exit(1);
  }  
  load_and_execute_elf(argv);  
  loader_cleanup();
  
  return 0;
}
